﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Daesung.ApiCenter.Client;
using Daesung.ApiCenter.Client.Results.AddressService;
using Daesung.ApiCenter.Client.Results.AddressService.Data;
using Daesung.ApiCenter.Client.Results.MessageService.Data;
using DaesungApiCenterClientSampleForm.Api;

namespace DaesungApiCenterClientSampleForm
{
    public partial class MainWindow : Form
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAddress_Click(object sender, EventArgs e)
        {
            var window = new AddressWindow();
            window.Key = txtKey.Text;
            window.ProgramName = txtProgramName.Text;
            window.ShowDialog(this);
        }

        private void btnCrewMessage_Click(object sender, EventArgs e)
        {
            var window = new CrewMessageWindow();
            window.Key = txtKey.Text;
            window.ProgramName = txtProgramName.Text;
            window.ShowDialog(this);
        }

        private void btnNLeaderMessage_Click(object sender, EventArgs e)
        {
            var window = new NLeaderMessageWindow();
            window.Key = txtKey.Text;
            window.ProgramName = txtProgramName.Text;
            window.ShowDialog(this);
        }
    }
}
