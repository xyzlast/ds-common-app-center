﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using DaesungApiCenterClientSampleForm.Api;

namespace DaesungApiCenterClientSampleForm
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new DaesungApiCenterClientSampleForm.MainWindow());
            //var addressWindow = new AddressWindow();
            //var addressWindow = new CrewMessageWindow();
            //addressWindow.ProgramName = "TEST APP";
            //addressWindow.Key = "45759f05-03da-4b13-a2cb-dc2ebcdaf56a";
            //Application.Run(addressWindow);
            //Application.Run(new MainWindow());
        }
    }
}
