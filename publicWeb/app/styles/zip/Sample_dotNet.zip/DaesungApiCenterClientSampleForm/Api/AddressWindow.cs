﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Daesung.ApiCenter.Client;
using Daesung.ApiCenter.Client.Results.AddressService;
using Daesung.ApiCenter.Client.Results.AddressService.Data;

namespace DaesungApiCenterClientSampleForm.Api
{
    public partial class AddressWindow : Form
    {
        public string Key { get; set; }
        public string ProgramName { get; set; }

        private string _searchText;
        private int _currentPageIndex = 0;
        private int _searchType = 0;
        private string _sidoNumber;

        private Dictionary<string, string> _sidoList;

        private const string HelpJibeon = "ex : 서초1동 1425, 잠실동 245";
        private const string HelpRoad = "ex : 강남대로 3, 백제고분로19길 26";
        private const string HelpBuilding = "ex: 푸르지오, 디큐브";

        public AddressWindow()
        {
            InitializeComponent();

            _sidoList = new Dictionary<string, string>();
            lblHelp.Text = HelpJibeon;
            rdJibeon.Select();
        }

        private void rdJibeon_Click(object sender, EventArgs e)
        {
            cmbSido.Enabled = false;
            chkMerge.Enabled = true;
            lblHelp.Text = HelpJibeon;
        }

        private void rdRoad_Click(object sender, EventArgs e)
        {
            cmbSido.Enabled = true;
            chkMerge.Enabled = true;
            lblHelp.Text = HelpRoad;
            FillSidoList();
        }

        private void rdBuildingName_Click(object sender, EventArgs e)
        {
            cmbSido.Enabled = true;
            chkMerge.Enabled = false;
            lblHelp.Text = HelpBuilding;
            FillSidoList();
        }

        private void FillSidoList()
        {
            if(cmbSido.Items.Count != 0) return;

            AppClient client = new AppClient(ProgramName);
            var result = client.GetSiDoList(Key);
            if(result.IsOK)
            {
                foreach(var sido in result.Data)
                {
                    _sidoList.Add(sido.SiDoName, sido.SiDoNumber);
                    cmbSido.Items.Add(sido.SiDoName);
                }
                cmbSido.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("인증되지 않은 프로그램입니다. 인증키와 프로그램 이름을 확인 후 다시 선택해주세요.");
                cmbSido.Enabled = false;
                lblHelp.Text = HelpJibeon;
                rdJibeon.Checked = true;
                rdRoad.Checked = false;
                rdBuildingName.Checked = false;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            var searchText = txtSearchKey.Text;

            _currentPageIndex = 0;
            _searchText = searchText;

            if(rdJibeon.Checked)
            {
                _searchType = 0;
            }
            else if(rdRoad.Checked)
            {
                _sidoNumber = _sidoList[cmbSido.Text];
                _searchType = 1;
            }
            else if(rdBuildingName.Checked)
            {
                _sidoNumber = _sidoList[cmbSido.Text];
                _searchType = 2;
            }
            CallApiClient();
        }

        private void CallApiClient()
        {
            lblMessage.Text = "CommonApp을 호출하는 중입니다.";
            lblMessage.ForeColor = Color.Yellow;

            listAddress.Items.Clear();
            AppClient client = new AppClient(ProgramName);
            ResultOfSearchAddress result = null;
            if(_searchType == 0)
            {
                bool removeDuplicated = chkMerge.Checked;
                result = client.SearchByJibeon(Key, _searchText, removeDuplicated, _currentPageIndex, 10);
            }
            else if(_searchType == 1)
            {
                bool removeDuplicated = chkMerge.Checked;
                result = client.SearchByRoad(Key, _sidoNumber, _searchText, removeDuplicated, _currentPageIndex, 10);
            }
            else
            {
                result = client.SearchByBuildingName(Key, _sidoNumber, _searchText, _currentPageIndex, 10);
            }

            lblMessage.Text = result.Message;
            if(result.IsOK)
            {
                lblCurrentPageNumber.Text = _currentPageIndex.ToString();
                lblMessage.ForeColor = Color.Blue;
                FillAddressListView(result.Data);
            }
            else
            {
                lblMessage.ForeColor = Color.Red;
            }
        }

        private void FillAddressListView(IEnumerable<Address> addresses)
        {
            foreach(var address in addresses)
            {
                var listViewItem = new ListViewItem(address.PostCode);
                listViewItem.SubItems.Add(address.RoadAddress);
                listViewItem.SubItems.Add(address.JibeonAddress);
                listAddress.Items.Add(listViewItem);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(_searchText))
            {
                return;
            }
            _currentPageIndex++;
            CallApiClient();
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(_searchText))
            {
                return;
            }
            if(_currentPageIndex > 0)
            {
                _currentPageIndex--;
                CallApiClient();
            }
        }

    }
}
