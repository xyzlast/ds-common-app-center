﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Daesung.ApiCenter.Client;

namespace DaesungApiCenterClientSampleForm.Api
{
    public partial class CrewMessageWindow : Form
    {
        public string Key { get; set; }
        public string ProgramName { get; set; }

        public CrewMessageWindow()
        {
            InitializeComponent();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            var fromUser = txtFromUser.Text;
            var toUser = txtToUser.Text;
            var message = txtMessage.Text;
            var linkUrl = txtLinkUrl.Text;

            if( string.IsNullOrEmpty(fromUser) ||
                string.IsNullOrEmpty(toUser) ||
                string.IsNullOrEmpty(message) )
            {
                MessageBox.Show("보내는 사람, 받는 사람 또는 메세지가 비어있습니다.");
                return;
            }

            var client = new AppClient(ProgramName);
            var result = client.SendCrewMessage(Key, fromUser, toUser, message, linkUrl, chkForce.Checked);

            if(result.IsOK)
            {
                MessageBox.Show("Message가 정상적으로 전송되었습니다.");
            }
            else
            {
                MessageBox.Show(string.Format("Message 전송에 에러가 발생되었습니다. : {0}", result.Message));
            }
        }
    }
}
