﻿namespace DaesungApiCenterClientSampleForm.Api
{
    partial class AddressWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdBuildingName = new System.Windows.Forms.RadioButton();
            this.rdRoad = new System.Windows.Forms.RadioButton();
            this.rdJibeon = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkMerge = new System.Windows.Forms.CheckBox();
            this.lblHelp = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbSido = new System.Windows.Forms.ComboBox();
            this.txtSearchKey = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrev = new System.Windows.Forms.Button();
            this.lblCurrentPageNumber = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.listAddress = new System.Windows.Forms.ListView();
            this.cmPostCode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cmRoadAddress = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cmJibeonAddress = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdBuildingName);
            this.groupBox1.Controls.Add(this.rdRoad);
            this.groupBox1.Controls.Add(this.rdJibeon);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(102, 118);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "검색 Type";
            // 
            // rdBuildingName
            // 
            this.rdBuildingName.AutoSize = true;
            this.rdBuildingName.Location = new System.Drawing.Point(6, 64);
            this.rdBuildingName.Name = "rdBuildingName";
            this.rdBuildingName.Size = new System.Drawing.Size(87, 16);
            this.rdBuildingName.TabIndex = 3;
            this.rdBuildingName.TabStop = true;
            this.rdBuildingName.Text = "건물명 검색";
            this.rdBuildingName.UseVisualStyleBackColor = true;
            this.rdBuildingName.Click += new System.EventHandler(this.rdBuildingName_Click);
            // 
            // rdRoad
            // 
            this.rdRoad.AutoSize = true;
            this.rdRoad.Location = new System.Drawing.Point(6, 42);
            this.rdRoad.Name = "rdRoad";
            this.rdRoad.Size = new System.Drawing.Size(87, 16);
            this.rdRoad.TabIndex = 2;
            this.rdRoad.TabStop = true;
            this.rdRoad.Text = "도로명 검색";
            this.rdRoad.UseVisualStyleBackColor = true;
            this.rdRoad.Click += new System.EventHandler(this.rdRoad_Click);
            // 
            // rdJibeon
            // 
            this.rdJibeon.AutoSize = true;
            this.rdJibeon.Location = new System.Drawing.Point(6, 20);
            this.rdJibeon.Name = "rdJibeon";
            this.rdJibeon.Size = new System.Drawing.Size(75, 16);
            this.rdJibeon.TabIndex = 1;
            this.rdJibeon.TabStop = true;
            this.rdJibeon.Text = "지번 검색";
            this.rdJibeon.UseVisualStyleBackColor = true;
            this.rdJibeon.Click += new System.EventHandler(this.rdJibeon_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chkMerge);
            this.groupBox2.Controls.Add(this.lblHelp);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cmbSido);
            this.groupBox2.Controls.Add(this.txtSearchKey);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(122, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(244, 118);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "검색조건";
            // 
            // chkMerge
            // 
            this.chkMerge.AutoSize = true;
            this.chkMerge.Location = new System.Drawing.Point(156, 76);
            this.chkMerge.Name = "chkMerge";
            this.chkMerge.Size = new System.Drawing.Size(72, 16);
            this.chkMerge.TabIndex = 4;
            this.chkMerge.Text = "중복제거";
            this.chkMerge.UseVisualStyleBackColor = true;
            // 
            // lblHelp
            // 
            this.lblHelp.Font = new System.Drawing.Font("Gulim", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblHelp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblHelp.Location = new System.Drawing.Point(10, 96);
            this.lblHelp.Name = "lblHelp";
            this.lblHelp.Size = new System.Drawing.Size(221, 12);
            this.lblHelp.TabIndex = 3;
            this.lblHelp.Text = "Sample Text";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "검색 시, 도 :";
            // 
            // cmbSido
            // 
            this.cmbSido.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSido.FormattingEnabled = true;
            this.cmbSido.Location = new System.Drawing.Point(137, 16);
            this.cmbSido.Name = "cmbSido";
            this.cmbSido.Size = new System.Drawing.Size(94, 20);
            this.cmbSido.TabIndex = 2;
            // 
            // txtSearchKey
            // 
            this.txtSearchKey.Location = new System.Drawing.Point(63, 54);
            this.txtSearchKey.Name = "txtSearchKey";
            this.txtSearchKey.Size = new System.Drawing.Size(168, 21);
            this.txtSearchKey.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "검색어 :";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnNext);
            this.groupBox4.Controls.Add(this.btnPrev);
            this.groupBox4.Controls.Add(this.lblCurrentPageNumber);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.listAddress);
            this.groupBox4.Location = new System.Drawing.Point(12, 136);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(689, 218);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Result";
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(606, 180);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 3;
            this.btnNext.Text = ">>";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrev
            // 
            this.btnPrev.Location = new System.Drawing.Point(525, 180);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(75, 23);
            this.btnPrev.TabIndex = 3;
            this.btnPrev.Text = "<<";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // lblCurrentPageNumber
            // 
            this.lblCurrentPageNumber.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblCurrentPageNumber.Location = new System.Drawing.Point(86, 180);
            this.lblCurrentPageNumber.Name = "lblCurrentPageNumber";
            this.lblCurrentPageNumber.Size = new System.Drawing.Size(30, 23);
            this.lblCurrentPageNumber.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 12);
            this.label5.TabIndex = 1;
            this.label5.Text = "현재 Page : ";
            // 
            // listAddress
            // 
            this.listAddress.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.cmPostCode,
            this.cmRoadAddress,
            this.cmJibeonAddress});
            this.listAddress.Location = new System.Drawing.Point(6, 20);
            this.listAddress.Name = "listAddress";
            this.listAddress.Size = new System.Drawing.Size(675, 157);
            this.listAddress.TabIndex = 0;
            this.listAddress.UseCompatibleStateImageBehavior = false;
            this.listAddress.View = System.Windows.Forms.View.Details;
            // 
            // cmPostCode
            // 
            this.cmPostCode.Text = "우편번호";
            this.cmPostCode.Width = 89;
            // 
            // cmRoadAddress
            // 
            this.cmRoadAddress.Text = "도로명 주소";
            this.cmRoadAddress.Width = 280;
            // 
            // cmJibeonAddress
            // 
            this.cmJibeonAddress.Text = "지번주소";
            this.cmJibeonAddress.Width = 282;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(372, 16);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(321, 114);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "검색";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.Location = new System.Drawing.Point(4, 17);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(677, 23);
            this.lblMessage.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lblMessage);
            this.groupBox3.Location = new System.Drawing.Point(12, 360);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(689, 52);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Message";
            // 
            // AddressWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(710, 425);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.btnSearch);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "AddressWindow";
            this.Text = "AddressWindow";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdBuildingName;
        private System.Windows.Forms.RadioButton rdRoad;
        private System.Windows.Forms.RadioButton rdJibeon;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkMerge;
        private System.Windows.Forms.Label lblHelp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbSido;
        private System.Windows.Forms.TextBox txtSearchKey;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.Label lblCurrentPageNumber;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListView listAddress;
        private System.Windows.Forms.ColumnHeader cmPostCode;
        private System.Windows.Forms.ColumnHeader cmRoadAddress;
        private System.Windows.Forms.ColumnHeader cmJibeonAddress;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}