﻿namespace DaesungApiCenterClientSampleForm
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtProgramName = new System.Windows.Forms.TextBox();
            this.txtKey = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnAddress = new System.Windows.Forms.Button();
            this.btnCrewMessage = new System.Windows.Forms.Button();
            this.btnNLeaderMessage = new System.Windows.Forms.Button();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtProgramName);
            this.groupBox5.Controls.Add(this.txtKey);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Location = new System.Drawing.Point(3, 12);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(312, 78);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "설정";
            // 
            // txtProgramName
            // 
            this.txtProgramName.Location = new System.Drawing.Point(98, 45);
            this.txtProgramName.Name = "txtProgramName";
            this.txtProgramName.Size = new System.Drawing.Size(119, 21);
            this.txtProgramName.TabIndex = 0;
            this.txtProgramName.Text = "TEST APP";
            // 
            // txtKey
            // 
            this.txtKey.Location = new System.Drawing.Point(47, 21);
            this.txtKey.Multiline = true;
            this.txtKey.Name = "txtKey";
            this.txtKey.Size = new System.Drawing.Size(249, 18);
            this.txtKey.TabIndex = 0;
            this.txtKey.Text = "45759f05-03da-4b13-a2cb-dc2ebcdaf56a";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "키값 :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "프로그램 이름 :";
            // 
            // btnAddress
            // 
            this.btnAddress.Location = new System.Drawing.Point(3, 96);
            this.btnAddress.Name = "btnAddress";
            this.btnAddress.Size = new System.Drawing.Size(312, 44);
            this.btnAddress.TabIndex = 4;
            this.btnAddress.Text = "주소검색 Sample";
            this.btnAddress.UseVisualStyleBackColor = true;
            this.btnAddress.Click += new System.EventHandler(this.btnAddress_Click);
            // 
            // btnCrewMessage
            // 
            this.btnCrewMessage.Location = new System.Drawing.Point(3, 146);
            this.btnCrewMessage.Name = "btnCrewMessage";
            this.btnCrewMessage.Size = new System.Drawing.Size(312, 44);
            this.btnCrewMessage.TabIndex = 4;
            this.btnCrewMessage.Text = "CrewMessenger Sample";
            this.btnCrewMessage.UseVisualStyleBackColor = true;
            this.btnCrewMessage.Click += new System.EventHandler(this.btnCrewMessage_Click);
            // 
            // btnNLeaderMessage
            // 
            this.btnNLeaderMessage.Location = new System.Drawing.Point(3, 196);
            this.btnNLeaderMessage.Name = "btnNLeaderMessage";
            this.btnNLeaderMessage.Size = new System.Drawing.Size(312, 44);
            this.btnNLeaderMessage.TabIndex = 4;
            this.btnNLeaderMessage.Text = "NLeader 업무전달 Sample";
            this.btnNLeaderMessage.UseVisualStyleBackColor = true;
            this.btnNLeaderMessage.Click += new System.EventHandler(this.btnNLeaderMessage_Click);
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(321, 256);
            this.Controls.Add(this.btnNLeaderMessage);
            this.Controls.Add(this.btnCrewMessage);
            this.Controls.Add(this.btnAddress);
            this.Controls.Add(this.groupBox5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MainWindow";
            this.Text = "MainWindow";
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtProgramName;
        private System.Windows.Forms.TextBox txtKey;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAddress;
        private System.Windows.Forms.Button btnCrewMessage;
        private System.Windows.Forms.Button btnNLeaderMessage;

    }
}

