var app = { };
app.baseUrl = 'http://app.daesungis.co.kr';
//app.baseUrl = 'http://localhost:3803';

app.base = {
    callJsonp: function (url, data, sucessCallMethod) {
        $.support.cors = true;
        $.ajax({
            url: url,
            dataType: 'jsonp',
            data: data,
            success: function (jsonResult) {
                eval(sucessCallMethod + '(jsonResult);');
            }
        });
    }
};

app.message = {
  sendCrewMessage: function(key, fromUser, toUser, message, linkUrl, force, successCallMethod) {
    var url = app.baseUrl + '/Api/Message/SendCrewMessage?callback=?';
    var data = {
                  key:key,
                  fromUser:fromUser,
                  toUser:toUser,
                  message:message,
                  linkUrl:linkUrl,
                  force:force
    };
    app.base.callJsonp(url, data, successCallMethod);
  },
  
  sendNLeaderMessage: function(key, fromUser, toUser, title, content, force, successCallMethod) {
    var url = app.baseUrl + '/Api/Message/SendNLeaderMessage?callback=?';
    var data = {
                  key:key,
                  fromUser:fromUser,
                  toUser:toUser,
                  title:title,
                  content:content,
                  force:force
    };
    app.base.callJsonp(url, data, successCallMethod);
  }
};

app.address = {
    getSidoList: function (key, sucessCallMethod) {
        var url = app.baseUrl + '/Address/GetSiDoList?callback=?';
        var data = { key: key };
        app.base.callJsonp(url, data, sucessCallMethod);
    },

    searchByJibeon: function (key, jibeonName, merge, pageIndex, pageSize, successCallMethod) {
        var url = app.baseUrl + '/Address/SearchByJibeon?callback=?';
        var data = {
            key: key,
            mergeJibeon : merge,
            jibeonName: jibeonName,
            pageIndex: pageIndex,
            pageSize: pageSize
        };
        app.base.callJsonp(url, data, successCallMethod);
    },

    searchByRoad: function (key, sidoNumber, roadName, merge, pageIndex, pageSize, successCallMethod) {
        var url = app.baseUrl + '/Address/SearchByRoad?callback=?';
        var data = {
            key: key,
            sidoNumber: sidoNumber,
            merge : merge,
            roadName: roadName,
            pageIndex: pageIndex,
            pageSize: pageSize
        };
        app.base.callJsonp(url, data, successCallMethod);
    },

    searchByBuildingName: function (key, sidoNumber, buildingName, pageIndex, pageSize, successCallMethod) {
        var url = app.baseUrl + '/Address/SearchByBuildingName?callback=?';
        var data = {
            key: key,
            sidoNumber: sidoNumber,
            buildingName: buildingName,
            pageIndex: pageIndex,
            pageSize: pageSize
        };
        app.base.callJsonp(url, data, successCallMethod);
    },
};